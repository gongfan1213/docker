<!-- https://www.ab62.cn/article/22334.html -->

能否再加一章简单的系统部署，一个PHP脚本，访问MySQL，从数据库中select一条记录，显示。
目前14章代码太多，作为入门书，看起来头晕。